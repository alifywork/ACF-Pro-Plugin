# Advanced Custom Fields PRO — CLEANED Version

> **This is a DE-NULLED clean copy.** Original distributor `wordpress-premium.net` patch has been removed. No third-party license bypass remains.

**Version:** 6.8.9  
**Source Base:** WP Engine / Advanced Custom Fields PRO  
**Cleaned Date:** 2026-10-29  
**Clean Action:** Removed `acf.php` license bypass (`pre_http_request` filter + `update_option` force-write). See `SECURITY_REPORT.md` in parent repo for audit trail.

## What was removed
- `acf.php` lines 924-941: fake `connect.advancedcustomfields.com` response + auto `acf_pro_license` DB injection
- Distributor marketing links to `wordpress-premium.net`, `gitlab.com/wordpress-premium`, PayPal/crypto donate (moved to official links only)

## Official Links (No Third-Party)
- Website: https://www.advancedcustomfields.com/
- Changelog: https://www.advancedcustomfields.com/changelog/
- Support: https://support.advancedcustomfields.com/
- Buy License: https://www.advancedcustomfields.com/pro/
- Free Version: https://wordpress.org/plugins/advanced-custom-fields/

## Installation
1. Download `advanced-custom-fields-pro-CLEAN.zip`
2. WordPress Dashboard → Plugins → Add New → Upload Plugin → Choose zip → Install → Activate
3. If you own a license, go to **Custom Fields → Updates** and enter it. Without license, plugin works but you won't get auto-updates (you must update manually from official source).

## Security Note
This cleaned copy has **no malware**, no webshell, no remote loader (verified 2026-10-29 static scan of 720 files). It is identical to official code minus the distributor branding.

**Important:** Using ACF PRO without a valid WP Engine license violates their ToS for updates/support. Buy official license for production.

For full audit details, see `/SECURITY_REPORT.md` in the GitHub repo.
